Rolling-Chocolate-Sales-Report/
│
├── Rolling_Chocolate_Sales_Report.pbix
├── chocolate_sales_data.csv
├── README.md
└── images/
    └── dashboard_preview.png
